const express = require("express");
const path = require("path");

const app = express();
const PORT = 3002;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.set("view engine", "ejs");

let feedbackList = [];

app.get("/", (req, res) => {
    res.render("feedback");
});

app.post("/submit-feedback", (req, res) => {
    const { name, email, category, message, rating } = req.body;

    if (
        !name ||
        !email ||
        !email.includes("@") ||
        !category ||
        !message ||
        message.length < 10
    ) {
        return res.send("Invalid input. Please go back and enter valid details.");
    }

    feedbackList.push({
        name,
        email,
        category,
        message,
        rating,
        date: new Date().toLocaleString()
    });

    res.render("thankyou");
});

app.get("/admin", (req, res) => {
    res.render("admin", { feedbacks: feedbackList });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
