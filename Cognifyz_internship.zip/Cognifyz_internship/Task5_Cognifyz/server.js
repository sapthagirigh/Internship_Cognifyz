const express = require("express");
const path = require("path");

const app = express();
const PORT = 3004;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

app.set("view engine", "ejs");

let feedbackList = [];

app.get("/", (req, res) => {
    res.render("feedback");
});

app.post("/api/feedback", (req, res) => {
    const { name, email, category, message, rating } = req.body;

    if (!name || !email || !category || !message || !rating) {
        return res.status(400).json({ error: "All fields are required" });
    }

    const feedback = {
        id: Date.now(),
        name,
        email,
        category,
        message,
        rating
    };

    feedbackList.push(feedback);
    res.json({ success: true });
});

app.get("/api/feedback", (req, res) => {
    res.json(feedbackList);
});

app.delete("/api/feedback/:id", (req, res) => {
    const id = parseInt(req.params.id);
    feedbackList = feedbackList.filter(fb => fb.id !== id);
    res.json({ success: true });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
