function submitFeedback() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const category = document.getElementById("category").value;
    const message = document.getElementById("message").value.trim();
    const rating = document.getElementById("rating").value;

    if (!name || !email || !category || !message || !rating) {
        document.getElementById("error").innerText = "All fields are required";
        return;
    }

    fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, category, message, rating })
    })
    .then(() => {
        clearForm();
        loadFeedback();
    });
}

function loadFeedback() {
    fetch("/api/feedback")
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("feedbackList");
            list.innerHTML = "";

            data.forEach(item => {
                const li = document.createElement("li");
                li.className = "list-group-item d-flex justify-content-between";

                li.innerHTML = `
                    <span>
                        <strong>${item.name}</strong> (${item.rating}/5)<br>
                        ${item.message}
                    </span>
                    <button class="btn btn-sm btn-danger"
                        onclick="deleteFeedback(${item.id})">
                        Delete
                    </button>
                `;

                list.appendChild(li);
            });
        });
}

function deleteFeedback(id) {
    fetch(`/api/feedback/${id}`, {
        method: "DELETE"
    }).then(loadFeedback);
}

function clearForm() {
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("category").value = "";
    document.getElementById("message").value = "";
    document.getElementById("rating").value = "";
    document.getElementById("error").innerText = "";
}

loadFeedback();
