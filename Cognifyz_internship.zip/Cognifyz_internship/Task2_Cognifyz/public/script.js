function validateForm() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const category = document.getElementById("category").value;
    const message = document.getElementById("message").value.trim();

    let error = "";

    if (name === "") {
        error = "Name is required";
    } else if (!email.includes("@")) {
        error = "Enter a valid email";
    } else if (category === "") {
        error = "Please select a category";
    } else if (message.length < 10) {
        error = "Feedback must be at least 10 characters";
    }

    if (error !== "") {
        document.getElementById("error").innerText = error;
        return false;
    }

    return true;
}
