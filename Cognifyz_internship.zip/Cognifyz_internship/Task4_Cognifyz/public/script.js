function countChars() {
    const msg = document.getElementById("message").value;
    document.getElementById("charCount").innerText = msg.length + " / 100";
}

function checkPasswordStrength() {
    const pwd = document.getElementById("password").value;
    const bar = document.getElementById("passwordStrengthBar");
    const text = document.getElementById("passwordStrengthText");

    let strength = 0;
    if (pwd.length >= 8) strength++;
    if (/[a-z]/.test(pwd)) strength++;
    if (/[A-Z]/.test(pwd)) strength++;
    if (/[0-9]/.test(pwd)) strength++;
    if (/[^A-Za-z0-9]/.test(pwd)) strength++;

    if (pwd.length === 0) {
        bar.style.width = "0%";
        bar.className = "progress-bar";
        text.innerText = "";
        return;
    }

    if (strength <= 2) {
        bar.style.width = "33%";
        bar.className = "progress-bar bg-danger";
        text.innerText = "Weak";
    } else if (strength === 3 || strength === 4) {
        bar.style.width = "66%";
        bar.className = "progress-bar bg-warning";
        text.innerText = "Medium";
    } else {
        bar.style.width = "100%";
        bar.className = "progress-bar bg-success";
        text.innerText = "Strong";
    }
}

function validateForm() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const category = document.getElementById("category").value;
    const message = document.getElementById("message").value.trim();
    const rating = document.getElementById("rating").value;

    document.getElementById("error").innerText = "";
    document.getElementById("nameError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("passwordError").innerText = "";
    document.getElementById("categoryError").innerText = "";
    document.getElementById("messageError").innerText = "";
    document.getElementById("ratingError").innerText = "";

    let isValid = true;

    if (name.length < 3 || !/^[A-Za-z ]+$/.test(name)) {
        document.getElementById("nameError").innerText =
            "Name must be at least 3 letters and contain only alphabets.";
        isValid = false;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").innerText = "Enter a valid email address.";
        isValid = false;
    }

    const pwdPattern =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
    if (!pwdPattern.test(password)) {
        document.getElementById("passwordError").innerText =
            "Password is not strong enough.";
        isValid = false;
    }

    if (category === "") {
        document.getElementById("categoryError").innerText = "Please select a category.";
        isValid = false;
    }

    if (message.length < 10 || message.length > 100) {
        document.getElementById("messageError").innerText =
            "Feedback must be between 10 and 100 characters.";
        isValid = false;
    }

    if (rating === "") {
        document.getElementById("ratingError").innerText = "Please select a rating.";
        isValid = false;
    }

    if (!isValid) {
        document.getElementById("error").innerText = "Please fix the errors above.";
        return false;
    }

    return true;
}

function showRoute() {
    const hash = window.location.hash || "#form";

    const formRoute = document.getElementById("route-form");
    const summaryRoute = document.getElementById("route-summary");
    const linkForm = document.getElementById("link-form");
    const linkSummary = document.getElementById("link-summary");

    if (hash === "#summary") {
        formRoute.classList.add("d-none");
        summaryRoute.classList.remove("d-none");

        linkForm.classList.remove("active");
        linkSummary.classList.add("active");
    } else {
        formRoute.classList.remove("d-none");
        summaryRoute.classList.add("d-none");

        linkForm.classList.add("active");
        linkSummary.classList.remove("active");
    }
}

window.addEventListener("hashchange", showRoute);
window.addEventListener("load", showRoute);
