const express = require("express");
const path = require("path");
const app = express();
const PORT = 3003;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  const { name, email, category, message, rating } = req.query;

  const hasData =
    name && email && category && message && rating;

  res.render("index", {
    feedback: hasData
      ? { name, email, category, message, rating }
      : null,
  });
});

app.post("/submit-feedback", (req, res) => {
  const { name, email, password, category, message, rating } = req.body;

  if (!name || !email || !password || !category || !message || !rating) {
    return res.redirect("/#form");
  }

  const params = new URLSearchParams({
    name,
    email,
    category,
    message,
    rating,
  }).toString();

  return res.redirect("/?" + params + "#summary");
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
