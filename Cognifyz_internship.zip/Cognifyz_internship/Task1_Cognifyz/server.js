const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.set("view engine", "ejs");

let feedbackList = [];

app.get("/", (req, res) => {
    res.render("feedback");
});

app.post("/submit-feedback", (req, res) => {
    const { name, email, category, message, rating } = req.body;

    if (!name || !email || !category || !message) {
        return res.send("All fields are required!");
    }

    const feedbackData = {
        name: name,
        email: email,
        category: category,
        message: message,
        rating: rating,
        date: new Date().toLocaleString()
    };

    feedbackList.push(feedbackData);

    res.render("thankyou");
});

app.get("/admin", (req, res) => {
    res.render("admin", { feedbacks: feedbackList });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
